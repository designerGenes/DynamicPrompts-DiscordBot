import discord
import random
import os

token = "MTE1MDgwMjk1Njc1MzU3NjEyOA.GuEfNl.x_g0Y2JH3bXYUpYqXTmuxn-tQlUnTCrbCeW7D4"
client = discord.Client()

async def read_file(filename):
    try:
        # Try reading the .txt file first
        with open(os.path.join('wildcards', f'{filename}.txt'), 'r') as f:
            lines = f.readlines()
    except FileNotFoundError:
        try:
            # If .txt file is not found, try without extension
            with open(os.path.join('wildcards', filename), 'r') as f:
                lines = f.readlines()
        except FileNotFoundError:
            return None
    
    return [line.strip() for line in lines]

async def replace_wildcards(text):
    start = text.find('[')
    end = text.find(']')
    
    while start != -1 and end != -1:
        wildcard = text[start+1:end]
        file_content = await read_file(wildcard)
        
        if file_content:
            replacement = random.choice(file_content)
            text = text[:start] + replacement + text[end+1:]
        
        start = text.find('[', end)
        end = text.find(']', start)
    
    return text

@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('!wildcard '):
        formatted_text = message.content[len('!wildcard '):]
        updated_text = await replace_wildcards(formatted_text)
        await message.channel.send(updated_text)

client.run(token)
